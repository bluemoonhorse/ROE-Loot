# ROE Loot Table Studio — Windows desktop app

A native C# WPF application. It opens as a desktop window and does not use a browser or local web server.

## Start

Extract the complete ZIP to a folder and double-click `RoeLootStudio.exe` from that folder. Keep the neighboring DLL and JSON files together. This framework-dependent build uses the .NET 10 Windows Desktop runtime installed on this machine.

## Edit loot

- Browse the loot or vehicle groups; edit group fields and table rows.
- Use the global English/Russian selector. The item translations tab edits both display names.
- **Add item** opens a searchable catalog sorted by item family and numeric ID. It includes selection weight (`iCount`), stack quantity (`iStackCount`), two primary extra-item chance choices, and up to four attachment/alternative choices with their own chance, pack count, and stack quantity.
- Imported and newly created `strItemName`, `strExtraItemName*`, and `strExtra2ItemName*` values are normalized to English wherever the catalog has a mapping. Russian names remain in the project translation map.
- Experimental IDs are available as labeled placeholders. They are not inserted into any loot group automatically. The source CSV does not identify AUG or SCAR-H internal IDs.

## JSON import and export

- **Open / Import** accepts editor project JSON, clean JSON with the four table arrays at the root, and the research wrapper emitted by `export_loot_tables_2022.py` (table data under `.rows`). H1/H2 placement outputs are simulation plans, not loot tables, and are rejected as such.
- **Save** writes the editable project to `%LOCALAPPDATA%\ROE Loot Table Studio\loot-project.json` and retains the 20 newest backups.
- **Export loot JSON** writes a portable four-table bundle with `map_id`, `control`, `items`, `vehicle_control`, and `vehicles` arrays. It omits research-only `source_line` fields and writes item names in English where mapped.
- **Export project** preserves the editor translation map as well as the four tables for future editing.
- CSV and XML table import remain available; CSV table export remains available for the currently selected group.

The scripts supplied with the data do not document the production server's JSON loader schema. The app exports a clean, direct four-table JSON handoff, but compatibility with the live server loader must be confirmed by its developer. See [loot-json-format-notes.md](loot-json-format-notes.md) and the [item ID catalog](roe-item-id-catalog.md).

